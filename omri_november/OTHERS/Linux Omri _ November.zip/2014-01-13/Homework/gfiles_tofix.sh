#!/bin/bash
while true; do
touch pic-date +s".jpg
sleep 0